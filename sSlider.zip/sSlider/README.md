sSlider
=======

A lightweight jQuery slider toolkit.

For more informations and to see the plugin in action, visit http://peppeocchi.github.io/sSlider/